#!/bin/bash

echo "AAA"
